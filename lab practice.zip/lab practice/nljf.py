from collections import deque

# Initial process data
process = [
    {'arrival': 0, 'burst': 5, 'complete': 0, 'turnaround': 0, 'waiting': 0, 'p': 'p1'},
    {'arrival': 1, 'burst': 3, 'complete': 0, 'turnaround': 0, 'waiting': 0, 'p': 'p2'},
    {'arrival': 2, 'burst': 4, 'complete': 0, 'turnaround': 0, 'waiting': 0, 'p': 'p3'},
    {'arrival': 4, 'burst': 1, 'complete': 0, 'turnaround': 0, 'waiting': 0, 'p': 'p4'},
]

# Sort function for queue based on burst time
def sort(q):
    temp = list(q)  # Convert deque to list
    temp.sort(key=lambda x: x['burst'])  # Sort by burst time
    return deque(temp)  # Return as deque

# Sort processes by arrival time
process.sort(key=lambda x: x['arrival'])

# Initialize variables
pro = process[:]
curr_time = process[0]['arrival']
q = deque()
store = []

# Add the first process to the queue
q.append(pro.pop(0))

# Main scheduling loop
while q:
    # Fetch the current process
    curr = q.popleft()

    # Simulate processing the current process for 1 unit of time
    curr_time += 1
    curr['burst'] -= 1

    # If the process is completed
    if curr['burst'] == 0:
        curr['complete'] = curr_time
        curr['turnaround'] = curr['complete'] - curr['arrival']
        curr['waiting'] = curr['turnaround'] - (curr['complete'] - curr['arrival'])
        store.append(curr)

    # Add newly arrived processes to the queue
    to_add = [p for p in pro if p['arrival'] <= curr_time]
    for p in to_add:
        q.append(p)
        pro.remove(p)

    # Re-add the current process if it is not complete
    if curr['burst'] > 0:
        q.append(curr)

    # Sort the queue by burst time
    q = sort(q)

# Display the processed list
print(store)
