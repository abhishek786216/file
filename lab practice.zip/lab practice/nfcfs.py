
process=[
    {
        'arrival':0,
        'burst':2,
        'complete':0,
        'turaround':0,
        'waiting':0,
        'p':'p1'
    },
    {
        'arrival':1,
        'burst':2,
        'complete':0,
        'waiting':0,
        'turaround':0,
        'p':'p2'
    },
    {
        'arrival':5,
        'burst':3,
        'complete':0,
        'turaround':0,
        'waiting':0,
        'p':'p3'
    },
    {
        'arrival':6,
        'burst':4,
        'complete':0,
        'turaround':0,
        'waiting':0,
        'p':'p4'
    },
   
]


for i in range(5):
    for j in range(3):
       if process[j]['arrival']>process[j+1]['arrival']:
            process[j],process[j+1]=process[j+1],process[j]
# print(process)

process[0]['complete']=process[0]['burst']+process[0]['arrival']

for i in range(1,len(process)):
    if process[i]['arrival']<=process[i-1]['complete']:
        process[i]['complete']=process[i-1]['complete']+process[i]['burst']
    else:
        process[i]['complete']=process[i-1]['complete']+process[i]['burst'] + process[i]['arrival']-process[i-1]['complete']

for p in process:
    p['turaround']=p['complete']-p['arrival']
    p['waiting']=p['turaround']-p['burst']

for p in process:
    print(p)
