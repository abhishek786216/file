block = [
    {'used': False, 'size': 200},
    {'used': False, 'size': 30},
    {'used': False, 'size': 700},
    {'used': False, 'size': 50}
]

process = [
    {'p': 'p1', 'large': 20},
    {'p': 'p2', 'large': 200},
    {'p': 'p3', 'large': 500},
    {'p': 'p4', 'large': 50},
]

for p in process:
    for b in block:
        if not b['used'] and p['large'] <= b['size']:
            b['used'] = True
            print(f"{p['p']} is acquired {b['size']}k")
            break
