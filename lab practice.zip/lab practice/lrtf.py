
from collections import deque
process = [
    {'arrival': 0, 'burst': 5, 'complete': 0, 'turnaround': 0, 'waiting': 0, 'p': 'p1'},
    {'arrival': 1, 'burst': 3, 'complete': 0, 'turnaround': 0, 'waiting': 0, 'p': 'p2'},
    {'arrival': 2, 'burst': 4, 'complete': 0, 'turnaround': 0, 'waiting': 0, 'p': 'p3'},
    {'arrival': 4, 'burst': 1, 'complete': 0, 'turnaround': 0, 'waiting': 0, 'p': 'p4'},
]


for i in range(len(process)):
    for j in range(len(process)-1):
        if(process[j]['arrival']>process[j+1]['arrival']):
            process[j],process[j+1]=process[j+1],process[j]

def sort(q):
    temp = list(q)  # Convert deque to a list
    temp.sort(key=lambda x: x['burst'])  # Sort in ascending order of burst time
    return deque(temp)  # Convert back to deque


curr=process[0]
com=curr['arrival']
process.remove(curr)

q=deque()
q.append(curr)
store=[]

while q:

    curr=q.popleft()
    if curr['burst'] == 0:
        curr['complete'] = com
        curr['turnaround'] = curr['complete'] - curr['arrival']
        curr['waiting'] = curr['turnaround'] - (curr['complete'] - curr['arrival'])
        store.append(curr)
    else:
        curr['burst']=curr['burst']-1
        q.append(curr)
        com=com+1
        if(len(process)!=0):
            for p in process:
                if(p['arrival']==com):
                    q.append(p)
    q=sort(q)


print(store)