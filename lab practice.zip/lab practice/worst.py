block = [
    {'used': False, 'size': 200},
    {'used': False, 'size': 30},
    {'used': False, 'size': 700},
    {'used': False, 'size': 50}
]

process = [
    {'p': 'p1', 'large': 20},
    {'p': 'p2', 'large': 200},
    {'p': 'p3', 'large': 500},
    {'p': 'p4', 'large': 50},
]

for p in process:
    temp = None  # Start with no suitable block
    for b in block:
        # Find the smallest unused block that can fit the process
        if not b['used'] and b['size'] >= p['large']:
            if temp is None or b['size'] < temp['size']:
                temp = b  # Update to the better-fitting block

    if temp:
        print(f"{p['p']} gets the block of size {temp['size']}")
        temp['used'] = True  # Mark block as used
    else:
        print(f"{p['p']} cannot be allocated a block.")
