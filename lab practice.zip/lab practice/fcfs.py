
process=[
    {
        'arrival':0,
        'burst':4,
        'complete':0,
        'turaround':0,
        'p':'p1'
    },
    {
        'arrival':1,
        'burst':3,
        'complete':0,
        'turaround':0,
        'p':'p2'
    },
    {
        'arrival':2,
        'burst':1,
        'complete':0,
        'turaround':0,
        'p':'p3'
    },
    {
        'arrival':3,
        'burst':2,
        'complete':0,
        'turaround':0,
        'p':'p4'
    },
    {
        'arrival':4,
        'burst':5,
        'complete':0,
        'turaround':0,
        'p':'p5'
    }
]

for i in range(4):
    for j in range(4):
        if process[j]['arrival'] > process[j+1]['arrival']:
            process[j],process[j+1]= process[j+1] ,process[j]


process[0]['complete']=process[0]['arrival']+process[0]['burst']
for i in range(1,5):
    if(process[i]['arrival']<=process[i-1]['complete']):
        process[i]['complete']=process[i]['burst']+process[i-1]['complete']
    else:
        process[i]['complete']=process[i]['burst']+process[i-1]['complete'] + process[i-1]['complete']-process[i]['arrival']


for p in process:
    p['turaround']=p['complete']-p['arrival']

avgtur=0
avgcom=0
for p in process:
    avgcom+=p['complete']
    avgtur+=p['turaround']
print(f' this is complete {avgcom/len(process)} and turaround {avgtur/len(process)}')
